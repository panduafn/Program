<?php include 'config/class.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<title>Pendaftaran Calon Pegawai Rumah Sakit Umum Pura Raharja Medika</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta name="description" content="Bootstrap 3 template for corporate business" />
	<!-- css -->
	<link href="css/bootstrap.min.css" rel="stylesheet" />
	<link href="css/cubeportfolio.min.css" rel="stylesheet" />
	<link href="css/style.css" rel="stylesheet" />


	<!-- Theme skin -->
	<link id="t-colors" href="skins/default.css" rel="stylesheet" />

	<!-- boxed bg -->
	<link id="bodybg" href="bodybg/bg1.css" rel="stylesheet" type="text/css" />
</head>

<body>



	<div id="wrapper">
		<!-- start header -->
		<header>
			<div class="top">
				<div class="container">
					<div class="row">
						<div class="col-md-6">
							<ul class="topleft-info">
								<li><i class="fa fa-phone"></i> +62 088 999 123</li>
							</ul>							
							<ul class="topleft-info">
								<li><i class="fa fa-envelope"></i> example@gmail.com</li>
							</ul>
						</div>
					</div>
				</div>
			</div>

			<div class="navbar navbar-default navbar-static-top">
				<div class="container">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
						<a class="navbar-brand" href="index.html"><img src="img/logoRS.png" alt="" width="100" height="60" /> Rumah Sakit Umum Pura Raharja Medika</a>
					</div>
				</div>
			</div>
		</header>
		<!-- end header -->
		
		<section id="content">
			<div class="container">

				<div class="row">
					<div class="col-xs-12 col-sm-8 col-md-6 col-sm-offset-2 col-md-offset-3">
						<form role="form" class="register-form" method="post">
							<h2>Sign in <small>manage your account</small></h2>
							<hr class="colorgraph">

							<div class="form-group">
								<input type="email" name="email" id="email" class="form-control input-lg" placeholder="Email Address" tabindex="4" required>
							</div>
							<div class="form-group">
								<input type="password" name="password" class="form-control input-lg" id="exampleInputPassword1" placeholder="Password" required>
							</div>

							<div class="row">
								<div class="col-xs-4 col-sm-3 col-md-3">
									<span class="button-checkbox">
						<button type="button" class="btn" data-color="info" tabindex="7">Remember me</button>
                        <input type="checkbox" name="t_and_c" id="t_and_c" class="hidden" value="1" required>
					</span>
								</div>
							</div>

							<hr class="colorgraph">
							<div class="row">
								<div class="col-xs-12 col-md-6"><button class="btn btn-success" name="login"> Sign In</button></div>
								<div class="col-xs-12 col-md-6">Don't have an account? <a href="daftar.php">Register</a></div>
							</div>
						</form>
						<?php  
						if (isset($_POST['login'])) 
						{
							$hasil=$pendaftaran->login_user($_POST['email'],$_POST['password']);
								if ($hasil=="sukses") 
							{
								 echo "<script>alert('Berhasil login!');</script>";
     							 echo "<script>location='dashboard.php';</script>";
							}
							else
							{
								 echo "<script>alert('Gagal login!');</script>";
     							 echo "<script>location='index.php';</script>";
							}
						}
						?>
					</div>
				</div>

			</div>
		</section>

		<footer>
			<div class="container">
				<div class="row">
					<div class="col-lg-3">
						<div class="widget">
							<h4>Address</h4>
							<address>
					<strong>Rumah Sakit Umum Pura Raharja Medika</strong><br>
					 Jl. Raya Brosot, Bangeran, Bumirejo, Kecamatan Lendah, Kabupaten Kulon Progo, Provinsi Daerah Istimewa Yogyakarta<br></address>
							<p>
								<i class="icon-phone"></i> (123) 456-7890 - (123) 555-7891 <br>
								<i class="icon-envelope-alt"></i> example@gmail.com
							</p>
						</div>
					</div>
					<div class="col-lg-3">
						<div class="widget">
							<h4>Information</h4>
							<ul class="link-list">
								<li><a href="#">Press release</a></li>
								<li><a href="#">Terms and conditions</a></li>
								<li><a href="#">Privacy policy</a></li>
								<li><a href="#">Career center</a></li>
								<li><a href="#">Contact us</a></li>
							</ul>
						</div>
					</div>
					
				</div>
			</div>
			<div id="sub-footer">
				<div class="container">
					<div class="row">
						<div class="col-lg-6">
							<div class="copyright">
								<p>&copy; Rumah Sakit Umum Pura Raharja Medika - All Right Reserved</p>
								<div class="credits">
									Designed by <a href="https://instagram.com/pandwafn">Panduafn</a>
								</div>
							</div>
						</div>
						
					</div>
				</div>
			</div>
		</footer>

	</div>
	<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
	<!-- javascript
    ================================================== -->
	<!-- Placed at the end of the document so the pages load faster -->
	<script src="js/jquery.min.js"></script>
	<script src="js/modernizr.custom.js"></script>
	<script src="js/jquery.easing.1.3.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.appear.js"></script>
	<script src="js/stellar.js"></script>
	<script src="js/classie.js"></script>
	<script src="js/uisearch.js"></script>
	<script src="js/jquery.cubeportfolio.min.js"></script>
	<script src="js/google-code-prettify/prettify.js"></script>
	<script src="js/animate.js"></script>
	<script src="js/custom.js"></script>


</body>

</html>
