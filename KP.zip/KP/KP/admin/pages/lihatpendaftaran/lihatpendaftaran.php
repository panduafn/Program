<?php  
$datapendaftar = $pendaftaran->tampilcalonpegawai();
$datenow = date('Y-m-d');
?>
<section class="invoice">
  <div class="row">
    <div class="col-xs-12">
      <h2 class="page-header">
        <i class="fa fa-list"></i> Cek Peserta Pendaftaran
        <small class="pull-right">Date: <?= tglIndonesia($datenow); ?></small>
      </h2>
    </div>
  </div>

  <div style="margin-top: 20px;" class="table table-responsive">
    <table id="example" class="table table-striped table-bordered table-hover">
      <thead>
        <tr>
          <th>No</th>
          <th>Nama Peserta</th>
          <th>Email</th>
          <th>Tanggal Lahir</th>
          <th>Jenis Kelamin</th>
          <th>Nomor Telepon</th>
          <th>Alamat</th>
          <th>Foto</th>
          <th>Surat Lamaran</th>
          <th>KTP</th>
          <th>Kartu Keluarga</th>
          <th>Ijazah</th>
          <th>Surat Tanda Registrasi</th>
          <th>Sertifikat PPGD</th>
          <th>Sertifikat BCLS</th>
          <th>Sertifikat BTCLS</th>
          <th>Hasil Periksa Kesehatan</th>
          <th>SKCK</th>
          <th>Surat Ijin Orang Tua/Suami/Istri</th>
          <th>Surat Pernyataan Taat Terhadap Peraturan Rumah Sakit</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($datapendaftar as $key => $value): ?>
        <tr>
          <td><?php echo $key+1; ?></td>
          <td><?php echo $value['nama_cal_peg'] ?></td>
          <td><?php echo $value['email_cal_peg'] ?></td>
          <td><?php echo $value['tgl_lahir'] ?></td>
          <td><?php echo $value['jenis_kelamin'] ?></td>
          <td><?php echo $value['no_telp'] ?></td>
          <td><?php echo $value['alamat_cal_peg'] ?></td>
          <td><?php echo $value['foto_cal_peg'] ?></td>
          <td><?php echo $value['surat_lamaran'] ?></td>
          <td><?php echo $value['ktp'] ?></td>
          <td><?php echo $value['kartu_kel'] ?></td>
          <td><?php echo $value['ijazah'] ?></td>
          <td><?php echo $value['surat_tanda_reg'] ?></td>
          <td><?php echo $value['sertifikat_ppgd'] ?></td>
          <td><?php echo $value['sertifikat_bcls'] ?></td>
          <td><?php echo $value['sertifikat_btcls'] ?></td>
          <td><?php echo $value['hasil_kes'] ?></td>
          <td><?php echo $value['skck'] ?></td>
          <td><?php echo $value['surat_ijin'] ?></td>
          <td><?php echo $value['surat_taat'] ?></td>
        <!-- <td>
          <a href="admin.php?halaman=editkategori&id=<?php echo $value["id_kategori"];?>" class="btn btn-warning"><i class="fa fa-pencil"></i> Edit</a>
          <a href="admin.php?halaman=hapuskategori&id=<?php echo $value["id_kategori"];?>" class="btn btn-danger" onclick="return confirm('Apakah anda yakin menghapus data ini ?')"><i class="fa fa-trash"></i> Hapus</a>
        </td> -->
      </tr>
    <?php endforeach ?>
  </tbody>
</table>
</div>

</section>


