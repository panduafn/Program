<?php  
$idlowongan=$_GET['id'];
$datapendaftar = $pendaftaran->tampilrangkinglowongan($idlowongan);
$datenow = date('Y-m-d');
?>
<section class="invoice">
  <div class="row">
    <div class="col-xs-12">
      <h2 class="page-header">
        <i class="fa fa-list"></i> Rangking Seleksi
        <small class="pull-right">Date: <?= tglIndonesia($datenow); ?></small>
      </h2>
    </div>
  </div>

  <div style="margin-top: 20px;" class="table table-responsive">
    <table id="example" class="table table-striped table-bordered table-hover">
      <thead>
        <tr>
          <th>No</th>
          <th>Nama Peserta</th>
          <th>Email</th>
          <th>Nilai Tes Tulis</th>
          <th>Kriteria Tes Tulis</th>
          <th>Nilai Tes Wawancara</th>
          <th>Kriteria Tes Wawancara</th>
          <th>Umur</th>
          <th>Kriteria Umur</th>
          <th>Pengalaman</th>
          <th>Kriteria Pengalaman</th>
          <th>Jarak</th>
          <th>Kriteria Jarak</th>
          <th>Hasil</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($datapendaftar as $key => $value): ?>
        <tr>
          <td><?php echo $key+1; ?></td>
          <td><?php echo $value['nama_cal_peg'] ?></td>
          <td><?php echo $value['email_cal_peg'] ?></td>
          <td><?php echo $value['nilai_tulis'] ?></td>
          <td><?php echo $value['kriteriaTulis'] ?></td>
          <td><?php echo $value['nilai_wawancara'] ?></td>
          <td><?php echo $value['kriteriaWawancara'] ?></td>
          <td><?php echo $value['umur'] ?></td>
          <td><?php echo $value['kriteriaUmur'] ?></td>
          <td><?php echo $value['lama_pengalaman'] ?></td>
          <td><?php echo $value['kriteriaPengalaman'] ?></td>
          <td><?php echo $value['jarak_rmh'] ?></td>
          <td><?php echo $value['kriteriaJarak'] ?></td>
          <td><?php echo round($value['hasil'],2) ?></td>
      </tr>
    <?php endforeach ?>
  </tbody>
</table>
</div>

</section>


