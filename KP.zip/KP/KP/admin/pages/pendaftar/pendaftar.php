<?php  
$datapendaftaran = $pendaftaran->ambilPendaftaran();
$datenow = date('Y-m-d');
?>
<section class="invoice">
  <div class="row">
    <div class="col-xs-12">
      <h2 class="page-header">
        <i class="fa fa-list"></i> DAFTAR LOWONGAN PENDAFTARAN
        <small class="pull-right">Date: <?= tglIndonesia($datenow); ?></small>
      </h2>
    </div>
  </div>

  <div style="margin-top: 20px;" class="table table-responsive">
    <table id="example" class="table table-striped table-bordered table-hover">
      <thead>
        <tr>
          <th>No</th>
          <th>Nama Pendaftaran</th>
          <th>Bobot Tulis</th>
          <th>Bobot Wawancara</th>
          <th>Bobot Umur</th>
          <th>Bobot Pengalaman</th>
          <th>Bobot Jarak Rumah</th>
          <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($datapendaftaran as $key => $value): ?>
        <tr>
          <td><?php echo $key+1; ?></td>
          <td><?php echo $value['nama_pendaftaran'] ?></td>
          <td><?php echo $value['bobot_tulis'] ?></td>
          <td><?php echo $value['bobot_wawancara'] ?></td>
          <td><?php echo $value['bobot_umur'] ?></td>
          <td><?php echo $value['bobot_pengalaman'] ?></td>
          <td><?php echo $value['bobot_jarakrmh'] ?></td>
          <td>
            <a href="admin.php?halaman=cekpendaftarlowongan&id=<?=$value['id_pendaftaran']?>" class="btn btn-warning">Lihat Pendaftar</a>
            <a href="admin.php?halaman=rangkingpendaftarlowongan&id=<?=$value['id_pendaftaran']?>" class="btn btn-success">Lihat Rangking Seleksi</a>
          </td>
      </tr>
    <?php endforeach ?>
  </tbody>
</table>
</div>

</section>


