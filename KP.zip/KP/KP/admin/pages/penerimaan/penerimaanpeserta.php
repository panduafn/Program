<?php 
$id_penilaian=$_GET['id'];
$datenow = date('Y-m-d');
?>

<section class="invoice">
  <div class="row">
    <div class="col-xs-12">
      <h2 class="page-header">
        <i class="fa fa-list"></i> Penilaian Calon Pegawai
        <small class="pull-right">Date: <?= tglIndonesia($datenow); ?></small>
      </h2>
    </div>
  </div>

                <form method="post">
                <div class="form-group">
                  <label>Nilai Test Tulis</label>
                  <input type="number" name="testulis" class="form-control">
                </div>

                <div class="form-group">
                  <label>Nilai Test Wawancara</label>
                   <input type="number" name="teswawancara" class="form-control">
                </div>

                <div class="form-group">
                  <label>Umur</label>
                 <input type="number" name="umur" class="form-control">
                </div>

                <div class="form-group">
                  <label>Lama Pengalaman</label>
                  <input type="number" name="lama_pengalaman" class="form-control">
                </div>

                <div class="form-group">
                  <label>Jarak Rumah</label>
                  <input type="number" name="jarakrmh" class="form-control">
                </div>
                
                    <button class="btn btn-primary" name="submit">Submit</button>
                </form>

                <?php  
                if (isset($_POST['submit'])) 
                {
                  $penilaian->editpenilaian($_POST['testulis'],$_POST['teswawancara'],$_POST['umur'],$_POST['lama_pengalaman'],$_POST['jarakrmh'],$id_penilaian);
                   echo "<script>alert('Data Nilai Sudah di Masukkan!');</script>";
                  echo "<script>location='admin.php?halaman=lihatpendaftar';</script>";
                }
                ?>

          </section>

