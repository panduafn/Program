<?php  
$databobot_saw = $bobot_saw->tampilbobot_saw();
$datenow = date('Y-m-d');
?>
<section class="invoice">
  <div class="row">
    <div class="col-xs-12">
      <h2 class="page-header">
        <i class="fa fa-list"></i> Perhitungan Nilai
        <small class="pull-right">Date: <?= tglIndonesia($datenow); ?></small>
      </h2>
    </div>
  </div>

   <div style="margin-top: 20px;" class="table table-responsive">
    <table id="example" class="table table-striped table-bordered table-hover">
      <thead>
        <tr>
          <th>No</th>
          <th>Nama Pendaftaran</th>
          <th>Bobot Test Tulis</th>
          <th>Bobot Test Wawancara</th>
          <th>Bobot Umur</th>
          <th>Bobot Pengalaman</th>
          <th>Bobot Jarak Rumah</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($databobot as $key => $value): ?>
        <tr>
          <td><?php echo $key+1; ?></td>
          <td><?php echo $value['nama_pendaftaran'] ?></td>
          <td><?php echo $value['bobot_tulis'] ?></td>
          <td><?php echo $value['bobot_wawancara'] ?></td>
          <td><?php echo $value['bobot_umur'] ?></td>
          <td><?php echo $value['bobot_pengalaman'] ?></td>
          <td><?php echo $value['bobot_jarakrmh'] ?></td>
        <!-- <td>
          <a href="admin.php?halaman=editkategori&id=<?php echo $value["id_kategori"];?>" class="btn btn-warning"><i class="fa fa-pencil"></i> Edit</a>
          <a href="admin.php?halaman=hapuskategori&id=<?php echo $value["id_kategori"];?>" class="btn btn-danger" onclick="return confirm('Apakah anda yakin menghapus data ini ?')"><i class="fa fa-trash"></i> Hapus</a>
        </td> -->
      </tr>
    <?php endforeach ?>
  </tbody>
</table>
</div>

</section>


