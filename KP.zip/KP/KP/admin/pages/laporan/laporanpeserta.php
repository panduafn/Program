<?php
$totalakademis = $pendaftaran->totalpendaftaranakademis();
$totalnonakademis = $pendaftaran->totalpendaftaranonakademis();
  $total =  $totalakademis+$totalnonakademis;
$datenow = date('Y-m-d');
?>
<section class="invoice">
  <div class="row">
    <div class="col-xs-12">
      <h2 class="page-header">
        <i class="fa fa-list"></i>  Laporan Peserta Pendaftaran
        <small class="pull-right">Date: <?= tglIndonesia($datenow); ?></small>
      </h2>
    </div>
  </div>

  <div style="margin-top: 20px;" class="table table-responsive">
    <table id="example" class="table table-striped table-bordered table-hover">
      <thead>
        <tr>
          <th>No</th>
          <th>Akademis</th>
          <th>Non-Akademis</th>
          <th>Jumlah Pendaftar</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>1</td>
        <td><?php echo $totalakademis; ?></td>
        <td><?php echo $totalnonakademis; ?></td>
        <td><?php echo $total; ?></td>
      </tr>
    </tbody>
    <tbody>
    </tbody>
  </table>
</div>
</section>