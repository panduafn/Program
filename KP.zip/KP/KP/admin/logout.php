<?php  
include '../config/class.php';
if (isset($_SESSION['admin'])) {
	unset($_SESSION['admin']);
}
 echo "<script>alert('Anda telah logout!');</script>";
      echo "<script>location='index.php';</script>";
?>