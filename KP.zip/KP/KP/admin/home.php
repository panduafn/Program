<div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="ion ion-ios-list-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Lihat Pendaftaran</span>
              <span class="info-box-number"><a href="admin.php?halaman=lihatpendaftar"><small>More Info <i class="fa fa-arrow-right"></i></small></a></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>

        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="ion ion-ios-people-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Cek Peserta</span>
              <span class="info-box-number"><a href="admin.php?halaman=cekpendaftar"><small>More Info <i class="fa fa-arrow-right"></i></small></a></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>

         <div class="clearfix visible-sm-block"></div>
         
<!--         <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="ion ion-ios-people-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Penerimaan Peserta</span>
              <span class="info-box-number"></span>
            </div>
          </div>
        </div> -->
            
            <div class="col-md-3 col-sm-6 col-xs-12">
              <div class="info-box">
                <span class="info-box-icon bg-orange"><i class="ion ion-ios-paper-outline"></i></span>
            
            <div class="info-box-content">
              <span class="info-box-text">Laporan</span>
                <span class="info-box-number"><a href="admin.php?halaman=laporanpendaftar"><small>More Info <i class="fa fa-arrow-right"></i></small></a></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>