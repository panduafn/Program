<!-- <?php
              if (isset($_POST['submit'])) 
              {
              $hasil=$penilaian->nilai($_POST['nilai_tulis'],$_POST['nilai_wawancara'],$_POST['umur'],$_POST['lama_pengalaman'],$_POST['jarak_rmh']);
              if ($hasil=="sukses") 
              {
                 echo "<script>alert('Data Nilai Sudah di Masukkan!');</script>";
                   echo "<script>location='penerimaanpeserta.php';</script>";
              }
              else
              {
                 echo "<script>alert('Data anda gaggal di Masukkan!');</script>";
                   echo "<script>location='penerimaanpeserta.php';</script>";
              }
            }
?> -->