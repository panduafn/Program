<?php include 'config/class.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<title>Pendaftaran Calon Pegawai Rumah Sakit Umum Pura Raharja Medika</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta name="description" content="Bootstrap 3 template for corporate business" />
	<!-- css -->
	<link href="css/bootstrap.min.css" rel="stylesheet" />
	<link href="plugins/flexslider/flexslider.css" rel="stylesheet" media="screen" />
	<link href="css/cubeportfolio.min.css" rel="stylesheet" />
	<link href="css/style.css" rel="stylesheet" />

	<!-- Theme skin -->
	<link id="t-colors" href="skins/default.css" rel="stylesheet" />

	<!-- boxed bg -->
	<link id="bodybg" href="bodybg/bg1.css" rel="stylesheet" type="text/css" />

</head>

<body>



	<div id="wrapper">
		<!-- start header -->
		<header>
			<div class="top">
				<div class="container">
					<div class="row">
						<div class="col-md-6">
							<ul class="topleft-info">
								<li><i class="fa fa-phone"></i> +62 088 999 123</li>
							</ul>
							<ul class="topleft-info">
								<li><i class="fa fa-envelope"></i> example@gmail.com</li>
							</ul>
							<?php if (isset($_SESSION['user'])): ?>
								
							<ul class="topleft-info">
								<li><a href="logout.php"><i class="fa fa-sign-out"></i> logout</a></li>
							</ul>
							<?php endif ?>
						</div>
						
					</div>
				</div>
			</div>

			<div class="navbar navbar-default navbar-static-top">
				<div class="container">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
						<a class="navbar-brand" href="index.html"><img src="img/logoRS.png" alt="" width="100" height="60" /> Rumah Sakit Umum Pura Raharja Medika</a>
					</div>
				</div>
			</div>
		</header>
		<!-- end header -->
		
		<br>
		<div class="container">
			<div class="row">
				<div class="panel panel-default">
					<div class="panel panel-body">
						<h3>Pendaftaran Calon Pegawai</h3>
						<form method="post" enctype="multipart/form-data">
							<div class="form-group">
								<label>Nama Lengkap</label>
								<input type="text" name="nama" placeholder="Masukan nama lengkap anda" class="form-control">
							</div>

							<div class="form-group">
								<label>Email</label>
								<input type="email" name="email" placeholder="Masukan email anda" class="form-control">
							</div>
							<div class="form-group">
								<label>Kata Sandi</label>
								<input type="password" name="sandi" placeholder="Masukkan Sandi" class="form-control">
							</div>
							
								<div class="form-group">
									<label>Tanggal Lahir</label>
									<input type="date" name="tanggallahir" class="form-control">
								</div>
							
							
								<div class="form-group">
									<label>Jenis Kelamin</label>
									<select class="form-control" name="jk">
										<option>-- Pilih Jenis Kelamin --</option>
										<option value="Laki-Laki">Laki-Laki</option>
										<option value="Perempuan">Perempuan</option>
									</select>
								</div>
						
						
								<div class="form-group">
									<label>Nomor Telepon</label>
									<input type="number" name="telp" placeholder="Masukan nomor telepon anda" class="form-control">
								</div>
					
						
								<div class="form-group">
									<label>Alamat</label>
									<textarea class="form-control" name="alamat" placeholder="Masukan Alamat"></textarea>
								</div>
								<div class="form-group">
									<label>Foto</label>
									<input type="file" name="gambar1" class="form-control">
								</div>
								<div class="form-group">
									<label>Surat Lamaran</label>
									<input type="file" name="gambar2" class="form-control">
								</div>
								<div class="form-group">
									<label>KTP</label>
									<input type="file" name="gambar3" class="form-control">
								</div>
								<div class="form-group">
									<label>Kartu Keluarga</label>
									<input type="file" name="gambar4" class="form-control">
								</div>
								<div class="form-group">
									<label>Ijazah</label>
									<input type="file" name="gambar5" class="form-control">
								</div>
								<div class="form-group">
									<label>Surat Tanda Registrasi (STR) / Surat Keterangan Sementara</label>
									<input type="file" name="gambar6" class="form-control">
								</div>
								<div class="form-group">
									<label>Sertifikat PPGD / Surat Keterangan Sementara</label>
									<input type="file" name="gambar7" class="form-control">
								</div>
								<div class="form-group">
									<label>Sertifikat BCLS / Surat Keterangan Sementara</label>
									<input type="file" name="gambar8" class="form-control">
								</div>
								<div class="form-group">
									<label>Sertifikat BTCLS / Surat Keterangan Sementara</label>
									<input type="file" name="gambar9" class="form-control">
								</div>
								<div class="form-group">
									<label>Hasil Periksa Kesehatan</label>
									<input type="file" name="gambar10" class="form-control">
								</div>
								<div class="form-group">
									<label>SKCK</label>
									<input type="file" name="gambar11" class="form-control">
								</div>
								<div class="form-group">
									<label>Surat Ijin Orang Tua/Suami/Istri</label>
									<input type="file" name="gambar12" class="form-control">
								</div>
								<div class="form-group">
									<label>Surat Pernyataan Taat Terhadap Peraturan Rumah Sakit</label>
									<input type="file" name="gambar13" class="form-control">
								</div>
						
							<button class="btn btn-primary" name="submit"> Submit</button>
						</form>
						<?php  
						if (isset($_POST['submit'])) 
						{
							$hasil=$pendaftaran->daftar($_POST['nama'],$_POST['email'],$_POST['sandi'],$_POST['tanggallahir'],$_POST['jk'],$_POST['telp'],$_POST['alamat'],$_FILES['gambar1'],$_FILES['gambar2'],$_FILES['gambar3'],$_FILES['gambar4'],$_FILES['gambar5'],$_FILES['gambar6'],$_FILES['gambar7'],$_FILES['gambar8'],$_FILES['gambar9'],$_FILES['gambar10'],$_FILES['gambar11'],$_FILES['gambar12'],$_FILES['gambar13']);
							if ($hasil=="sukses") 
							{
								 echo "<script>alert('Data anda sudah terdaftar pada sistem kami mohon untuk menunggu proses selanjutnya!');</script>";
     							 echo "<script>location='index.php';</script>";
							}
							else
							{
								 echo "<script>alert('Data anda gaggal disimpan, mungkin email yang anda daftarkan sudah terdaftar!');</script>";
     							 echo "<script>location='index.php';</script>";
							}
						}
						?>
					</div>
				</div>
			</div>
		</div>
		

		<footer>
			<div class="container">
				<div class="row">
					<div class="col-sm-3 col-lg-3">
						<div class="widget">
							<h4>Address</h4>
							<address>
					<strong>Rumah Sakit Pura Raharja Medika</strong><br>
					 Jl. Raya Brosot, Bangeran, Bumirejo, Kecamatan Lendah, Kabupaten Kulon Progo, Provinsi Daerah Istimewa Yogyakarta <br>
					 </address>
							<p>
								<i class="icon-phone"></i> +62 888 111 222 <br>
								<i class="icon-envelope-alt"></i> example@gmail.com
							</p>
						</div>
					</div>
					<div class="col-sm-3 col-lg-3">
						<div class="widget">
							<h4>Information</h4>
							<ul class="link-list">
								<li><a href="#">Press release</a></li>
								<li><a href="#">Terms and conditions</a></li>
								<li><a href="#">Privacy policy</a></li>
								<li><a href="#">Career center</a></li>
								<li><a href="#">Contact us</a></li>
							</ul>
						</div>

					</div>
				</div>
			</div>
			<div id="sub-footer">
				<div class="container">
					<div class="row">
						<div class="col-lg-6">
							<div class="copyright">
								<p>&copy; Rumah Sakit Pura Raharja Medika - All Right Reserved</p>
								<div class="credits">
									Designed by <a href="https://instagram.com/pandwafn">PanduAfn</a>
								</div>
							</div>
						</div>
						<div class="col-lg-6">
							<ul class="social-network">
								<li><a href="#" data-placement="top" title="Facebook"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#" data-placement="top" title="Twitter"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#" data-placement="top" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
								<li><a href="#" data-placement="top" title="Pinterest"><i class="fa fa-pinterest"></i></a></li>
								<li><a href="#" data-placement="top" title="Google plus"><i class="fa fa-google-plus"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</footer>
	</div>
	<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>

	<!-- Placed at the end of the document so the pages load faster -->
	<script src="js/jquery.min.js"></script>
	<script src="js/modernizr.custom.js"></script>
	<script src="js/jquery.easing.1.3.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="plugins/flexslider/jquery.flexslider-min.js"></script>
	<script src="plugins/flexslider/flexslider.config.js"></script>
	<script src="js/jquery.appear.js"></script>
	<script src="js/stellar.js"></script>
	<script src="js/classie.js"></script>
	<script src="js/uisearch.js"></script>
	<script src="js/jquery.cubeportfolio.min.js"></script>
	<script src="js/google-code-prettify/prettify.js"></script>
	<script src="js/animate.js"></script>
	<script src="js/custom.js"></script>


</body>

</html>
