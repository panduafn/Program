<?php 
include 'config/class.php';
if (isset($_GET['daftar'])) {
	$id=$_GET['id'];
	$id_cal_peg=$_SESSION['user']['kd_cal_peg'];
	$pendaftaran->daftarLowongan($id, $id_cal_peg);
	header("location: dashboard.php");
}
