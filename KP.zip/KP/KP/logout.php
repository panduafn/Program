<?php  
include 'config/class.php';
if (isset($_SESSION['user'])) {
	unset($_SESSION['user']);
}
 echo "<script>alert('Anda telah logout!');</script>";
      echo "<script>location='index.php';</script>";
?>