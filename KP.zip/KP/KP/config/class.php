<?php  

if (!isset($_SESSION)) 
{
	session_start();
}

$mysqli = new mysqli("localhost","root","","kp_2");
$home = 'http://localhost/KP/';
if (class_exists('admin')!=true) 
{
	class admin
	{
		public $koneksi;
		function __construct($mysqli)
		{
			$this->koneksi = $mysqli;
		}
		function login_admin($uname,$password)
		{
			$uname = mysqli_real_escape_string($this->koneksi,$uname);
			$password= mysqli_real_escape_string($this->koneksi,$password);
			$enpass=sha1($password);

			$ambil = $this->koneksi->query("SELECT * FROM admin WHERE uname_admin='$uname' AND pass_admin='$enpass' ");

			$yangcocok=$ambil->num_rows;
			if ($yangcocok==1) 
			{
				$akun=$ambil->fetch_assoc();

				$_SESSION["admin"]=$akun;
				return "sukses";
			}
			else
			{
				return "gagal";
			}
		}
		function ambiladmin($id_admin)
		{
			$ambil = $this->koneksi->query("SELECT * FROM admin WHERE id_admin='$id_admin' ");
			$pecahdata = $ambil->fetch_assoc();
			return $pecahdata;
		}
		function ubahadmin($nama,$email,$pass,$foto,$id_admin)
		{
			$enk=sha1($pass);
			$namagambar=$foto['name'];
			$lokasi=$foto['tmp_name'];
			if (!empty($namagambar)) {
				$adminlama=$this->ambiladmin($id_admin);
				$gambarlama=$adminlama['foto_admin'];
				if (file_exists("../img_admin/$gambarlama")) {
					unlink("../img_admin/$gambarlama");
				}
				move_uploaded_file($lokasi, "../img_admin/$namagambar");
				$this->koneksi->query("UPDATE admin SET nama_admin='$nama', email_admin='$email',  foto_admin='$namagambar' WHERE id_admin='$id_admin'");
			}
			elseif(empty($pass)) {
				$this->koneksi->query("UPDATE admin SET  nama_admin='$nama', email_admin='$email' WHERE id_admin='$id_admin'" ) ;
			}
			else{
				move_uploaded_file($lokasi, "../../img_admin/$namagambar");
				$this->koneksi->query("UPDATE admin SET  nama_admin='$nama', email_admin='$email',password_admin='$enk' WHERE id_admin='$id_admin'" ) ;
			}

			$detil=$this->ambiladmin($id_admin);
			$_SESSION["admin"]=$detil;
		}
	}
}



class pendaftaran
{
	public $koneksi;
	function __construct($mysqli)
	{
		$this->koneksi = $mysqli;
	}
	function ambilPendaftaran()
	{
		$ambil = $this->koneksi->query("SELECT * FROM bobot_saw");
		while ($pecahdata=$ambil->fetch_assoc()) 
		{
			$semuadata[]=$pecahdata;
		}
		return $semuadata;
	}
	function ambiltestimoni($id_testi)
	{
		$ambil = $this->koneksi->query("SELECT * FROM testimoni WHERE id_testi='$id_testi'");
		$pecahdata = $ambil->fetch_assoc();
		return $pecahdata;
	}
	function login_user($email,$password)
		{
			$email = mysqli_real_escape_string($this->koneksi,$email);
			$password= mysqli_real_escape_string($this->koneksi,$password);
			$enpass=md5($password);

			$ambil = $this->koneksi->query("SELECT * FROM calon_pegawai WHERE email_cal_peg='$email' AND sandi='$enpass' ");

			$yangcocok=$ambil->num_rows;
			if ($yangcocok==1) 
			{
				$akun=$ambil->fetch_assoc();

				$_SESSION["user"]=$akun;
				return "sukses";
			}
			else
			{
				return "gagal";
			}
		}
	function daftar($nama,$email,$sandi, $tanggallahir,$jk,$telp,$alamat,$gambar1,$gambar2,$gambar3,$gambar4,$gambar5,$gambar6,$gambar7,$gambar8,$gambar9,$gambar10,$gambar11,$gambar12,$gambar13)
	{
		$ambil = $this->koneksi->query("SELECT * FROM calon_pegawai WHERE email_cal_peg='$email'");

			$yangcocok=$ambil->num_rows;
			if ($yangcocok>0) 
			{
				return "gagal";
			}
			else
			{
				$nama1 = $gambar1['name'];
				$nama2 = $gambar2['name'];
				$nama3 = $gambar3['name'];
				$nama4 = $gambar4['name'];
				$nama5 = $gambar5['name'];
				$nama6 = $gambar6['name'];
				$nama7 = $gambar7['name'];
				$nama8 = $gambar8['name'];
				$nama9 = $gambar9['name'];
				$nama10 = $gambar10['name'];
				$nama11 = $gambar11['name'];
				$nama12 = $gambar12['name'];
				$nama13 = $gambar13['name'];
				$lokasi1 = $gambar1['tmp_name'];
				$lokasi2 = $gambar2['tmp_name'];
				$lokasi3 = $gambar3['tmp_name'];
				$lokasi4 = $gambar4['tmp_name'];
				$lokasi5 = $gambar5['tmp_name'];
				$lokasi6 = $gambar6['tmp_name'];
				$lokasi7 = $gambar7['tmp_name'];
				$lokasi8 = $gambar8['tmp_name'];
				$lokasi9 = $gambar9['tmp_name'];
				$lokasi10 = $gambar10['tmp_name'];
				$lokasi11 = $gambar11['tmp_name'];
				$lokasi12 = $gambar12['tmp_name'];
				$lokasi13 = $gambar13['tmp_name'];
				move_uploaded_file($lokasi1, "img_pendaftar/$nama1");
				move_uploaded_file($lokasi2, "img_pendaftar/$nama2");
				move_uploaded_file($lokasi3, "img_pendaftar/$nama3");
				move_uploaded_file($lokasi4, "img_pendaftar/$nama4");
				move_uploaded_file($lokasi5, "img_pendaftar/$nama5");
				move_uploaded_file($lokasi6, "img_pendaftar/$nama6");
				move_uploaded_file($lokasi7, "img_pendaftar/$nama7");
				move_uploaded_file($lokasi8, "img_pendaftar/$nama8");
				move_uploaded_file($lokasi9, "img_pendaftar/$nama9");
				move_uploaded_file($lokasi10, "img_pendaftar/$nama10");
				move_uploaded_file($lokasi11, "img_pendaftar/$nama11");
				move_uploaded_file($lokasi12, "img_pendaftar/$nama12");
				move_uploaded_file($lokasi13, "img_pendaftar/$nama13");
				$sandi=md5($sandi);
				$this->koneksi->query("INSERT INTO calon_pegawai (nama_cal_peg,email_cal_peg,sandi,tgl_lahir,jenis_kelamin,no_telp,alamat_cal_peg,foto_cal_peg,surat_lamaran,ktp,kartu_kel,ijazah,surat_tanda_reg,sertifikat_ppgd,sertifikat_bcls,sertifikat_btcls,hasil_kes,skck,surat_ijin,surat_taat) VALUES('$nama','$email','$sandi','$tanggallahir','$jk','$telp','$alamat','$nama1','$nama2','$nama3','$nama4','$nama5','$nama6','$nama7','$nama8','$nama9','$nama10','$nama11','$nama12','$nama13	') ");
				return "sukses";
			}
	}
		function tampilcalonpegawai()
		{
			$semuadata = array();
			$ambil = $this->koneksi->query("SELECT * FROM calon_pegawai ORDER BY kd_cal_peg ASC");
			while ($pecahdata=$ambil->fetch_assoc()) 
			{
				$semuadata[]=$pecahdata;
			}
			return $semuadata;
		}

		function tampilcalonpegawailowongan($idLowongan)
		{
			$semuadata = array();
			$ambil = $this->koneksi->query("SELECT * FROM calon_pegawai, penilaian where calon_pegawai.kd_cal_peg = penilaian.kd_cal_peg and id_pendaftaran='$idLowongan' ORDER BY calon_pegawai.kd_cal_peg ASC");
			while ($pecahdata=$ambil->fetch_assoc()) 
			{
				$semuadata[]=$pecahdata;
			}
			return $semuadata;
		}

		function tampilrangkinglowongan($idLowongan)
		{
			$data = array();
			$ambil = $this->koneksi->query("SELECT * from penilaian, calon_pegawai where id_pendaftaran='$idLowongan' and calon_pegawai.kd_cal_peg = penilaian.kd_cal_peg and nilai_tulis <> '0' and nilai_wawancara <> '0' and umur <> '0' and lama_pengalaman <> '0' and jarak_rmh <> '0'");
			while ($pecahdata=$ambil->fetch_assoc()) 
			{
				$data[]=$pecahdata;
			}
			$ambil = $this->koneksi->query("SELECT * from bobot_saw where id_pendaftaran='$idLowongan'");
			while ($pecahdata=$ambil->fetch_assoc()) 
			{
				$bobot=$pecahdata;
			}
			// echo print_r($bobot);
			$result=@simple_additive_weight($data, $bobot);
			return $result;
			// return $data;
		}

		function daftarLowongan($id_lowongan, $kd_cal_peg){
			$this->koneksi->query("INSERT INTO `penilaian`(`id_pendaftaran`, `kd_cal_peg`) VALUES ('$id_lowongan','$kd_cal_peg')");
		}

		function manualQuery($query){
			$semuadata = array();
			$ambil = $this->koneksi->query("$query");
			while ($pecahdata=$ambil->fetch_assoc()) 
			{
				$semuadata[]=$pecahdata;
			}
			return $semuadata; 

		}

	function edittestimoni($nama,$gambar,$id_testi)
	{
		$namagambar=$gambar['name'];
		$lokasi=$gambar['tmp_name'];
		if (!empty($lokasi)) {
			$testimonilama=$this->ambiltestimoni($id_testi);
			$gambarlama=$testimonilama['gbr_test'];
			if (file_exists("../../img_testimoni/$gambarlama")) {
				unlink("../../img_testimoni/$gambarlama");
			}
			move_uploaded_file($lokasi, "../../img_testimoni/$namagambar");
			$this->koneksi->query("UPDATE testimoni SET nm_test_pel='$nama', gbr_test='$namagambar' WHERE id_testi='$id_testi'");
		}else{
			$this->koneksi->query("UPDATE testimoni SET nm_test_pel='$nama' WHERE id_testi='$id_testi'");
		}
	}
	function hapustestimoni($id_testi){
		$datatesti=$this->ambiltestimoni($id_testi);
		$gambar=$datatesti['gbr_test'];
		if (file_exists("../../img_testimoni/$gambar")) {
			unlink("../../img_testimoni/$gambar");
		}
		$this->koneksi->query("DELETE FROM testimoni WHERE id_testi='$id_testi'");
	}
	function totalpendaftaranakademis()
	{
		$ambil=$this->koneksi->query("SELECT * FROM penilaian WHERE id_pendaftaran=2 ");
		$tot = $ambil->num_rows;
		return $tot;
	}
	function totalpendaftaranonakademis()
	{
		$ambil=$this->koneksi->query("SELECT * FROM penilaian WHERE id_pendaftaran=3 ");
		$tot = $ambil->num_rows;
		return $tot;
	}
}

class penilaiancalon
{
	public $koneksi;

		function __construct($mysqli)
		{
			$this->koneksi = $mysqli;
		}
		function editpenilaian($testulis,$teswawancara,$umur,$lama_pengalaman,$jarakrmh,$id_penilaian)
		{
			
				$this->koneksi->query("UPDATE penilaian SET nilai_tulis='$testulis', nilai_wawancara='$teswawancara', umur='$umur', lama_pengalaman='$lama_pengalaman', jarak_rmh='$jarakrmh' WHERE id_penilaian='$id_penilaian' ");
			
		}

}

if (class_exists('penilaian')!=true) 
{
	class penilaian
	{
		public $koneksi;

		function __construct($mysqli)
		{
			$this->koneksi = $mysqli;
		}

		function tambahnilai ($id_penilaian,$testulis,$teswawancara,$umur,$lama_pengalaman,$jarakrmh)
		{
			$ambil = $this->koneksi->query("SELECT * FROM penilaian WHERE id_penilaian='$id'");

			$yangcocok=$ambil->num_rows;
			// if ($yangcocok>0) 
			// {
			// 	return "gagal";
			// }
			// else
			// {
			// 	$nilai_tulis 		= $nilai1['name'];
			// 	$nilai_wawancara 	= $nilai2['name'];
			// 	$umur 				= $nilai3['name'];
			// 	$lama_pengalaman 	= $nilai4['name'];
			// 	$jarak_rmh 			= $nilai5['name'];


				$this->koneksi->query("INSERT INTO penilaian (nilai_tulis,nilai_wawancara,umur,lama_pengalaman,jarak_rmh) VALUES ('$testulis','$teswawancara','$umur','$lama_pengalaman','$jarakrmh'"); 
				return "sukses";
			}


		function ambilpenilaian($id_penilaian)
		{
			$ambil = $this->koneksi->query("SELECT * FROM penilaian WHERE id_penilaian='$id_penilaian' ");
			$pecahdata = $ambil->fetch_assoc();
			return $pecahdata;
		}
		function tampilpenilaian()
		{
			$semuadata = array();
			$ambil = $this->koneksi->query("SELECT * FROM penilaian ORDER BY id_penilaian ASC");
			while ($pecahdata=$ambil->fetch_assoc()) 
			{
				$semuadata[]=$pecahdata;
			}
			return $semuadata;
		}
		function tambahpenilaian($id_penilaian)
		{
			$ambil = $this->koneksi->query("SELECT * FROM penilaian WHERE id_penilaian='$id_penilaian' ");
			$yangcocok = $ambil->num_rows;
			if ($yangcocok > 0) {
				return "gagal";
			}
			else
			{
				$slug = $slug = str_replace(" ", "-", $id_penilaian);
				$this->koneksi->query("INSERT INTO penilaian (id_penilaian) VALUES ('$id_penilaian') ");
				return "sukses";
			}
		}
		function editpenilaian($testulis,$teswawancara,$umur,$lama_pengalaman,$jarakrmh,$id_penilaian)
		{
			
				$this->koneksi->query("UPDATE penilaian SET nilai_tulis='$testulis', nilai_wawancara='$teswawancara', umur='$umur', lama_pengalaman='$lama_pengalaman', jarak_rmh='$jarakrmh' WHERE id_penilaian='$id_penilaian' ");
			
		}
		function hapuspenilaian($id_penilaian)
		{
			$this->koneksi->query("DELETE FROM penilaian WHERE id_penilaian='$id_penilaian' ");
		}
			}
	}


	class bobot_saw 
	{
		public $koneksi;

		function bobot($id_pendaftaran,$nama_pendaftaran,$bobot_tulis,$bobot_wawancara,$bobot_umur,$bobot_pengalaman,$bobot_jarakrmh)
		{
			$ambil = $this->koneksi->query("SELECT * FROM bobot_saw ");

				$yangcocok=$ambil->num_rows;
				if ($yangcocok>0) 
				{
					return "gagal";
				}
				else
				{
					$id_pendaftaran 	= $id_pendaftaran['name'];
					$nama_pendaftaran 	= $nama_pendaftaran['name'];
					$bobot_tulis 		= $bobot1['name'];
					$bobot_wawancara 	= $bobot2['name'];
					$bobot_umur 		= $bobot3['name'];
					$bobot_pengalaman 	= $bobot4['name'];
					$bobot_jarakrmh 	= $bobot5['name'];
					$this->koneksi->query("INSERT INTO bobto_saw (id_pendaftaran,nama_pendaftaran,bobot_tulis,bobot_wawancara,bobot_umur,bobot_pengalaman,bobot_jarakrmh) VALUES('$id_pendaftaran','$nama_pendaftaran','$bobot1','$bobot2','$bobot3','$bobot4','$bobot5') ");
					return "sukses";
				}
		}
	function tampilbobot_saw()
		{
			$semuadata = array();
			$ambil = $this->koneksi->query("SELECT * FROM bobot_saw ORDER BY id_pendaftaran ASC");
			while ($pecahdata=$ambil->fetch_assoc()) 
			{
				$semuadata[]=$pecahdata;
			}
			return $semuadata;
		}
	}



function simple_additive_weight($data, $bobot){
	$result=null;
	for ($i=0; $i < count($data); $i++) { 
		$result[$i]=$data[$i];
	}
	//mencari nilai maks tes tulis
	$temp=null;
	for ($i=0; $i < count($data); $i++) { 
		$temp[]=$data[$i]['nilai_tulis'];
	}
	$maksNilaiTulis=max($temp);
	//menghitung nilai kriteria tes tulis
	for ($i=0; $i < count($data); $i++) { 
		$result[$i]['kriteriaTulis']=$data[$i]['nilai_tulis']/$maksNilaiTulis;
	}
	//mencari nilai maks tes wawancara
	$temp=null;
	for ($i=0; $i < count($data); $i++) { 
		$temp[]=$data[$i]['nilai_wawancara'];
	}
	$maksNilaiWawancara=max($temp);
	//menghitung nilai kriteria tes wawancara
	for ($i=0; $i < count($data); $i++) { 
		$result[$i]['kriteriaWawancara']=$data[$i]['nilai_wawancara']/$maksNilaiWawancara;
	}
	//mencari nilai min umur
	$temp=null;
	for ($i=0; $i < count($data); $i++) { 
		$temp[]=$data[$i]['umur'];
	}
	$minUmur=min($temp);
	//menghitung nilai kriteria umur
	for ($i=0; $i < count($data); $i++) { 
		$result[$i]['kriteriaUmur']=$minUmur/$data[$i]['umur'];
	}
	//mencari nilai maks pengalaman
	$temp=null;
	for ($i=0; $i < count($data); $i++) { 
		$temp[]=$data[$i]['lama_pengalaman'];
	}
	$maksLamaPengalaman=max($temp);
	//menghitung nilai kriteria pengalaman
	for ($i=0; $i < count($data); $i++) { 
		$result[$i]['kriteriaPengalaman']=$data[$i]['lama_pengalaman']/$maksLamaPengalaman;
	}
	//mencari nilai min jarak
	$temp=null;
	for ($i=0; $i < count($data); $i++) { 
		$temp[]=$data[$i]['jarak_rmh'];
	}
	$minJarak=min($temp);	
	//menghitung nilai kriteria jarak
	for ($i=0; $i < count($data); $i++) { 
		$result[$i]['kriteriaJarak']=$minJarak/$data[$i]['jarak_rmh'];
	}
	//menghitung hasil kriteria dikali bobot
	// echo print_r($bobot);
	for ($i=0; $i < count($data); $i++) { 
		$result[$i]['hasil']=$result[$i]['kriteriaTulis']*$bobot['bobot_tulis']+$result[$i]['kriteriaWawancara']*$bobot['bobot_wawancara']+$result[$i]['kriteriaUmur']*$bobot['bobot_umur']+$result[$i]['kriteriaPengalaman']*$bobot['bobot_pengalaman']+$result[$i]['kriteriaJarak']*$bobot['bobot_jarakrmh'];
	}

	$result=array_sort($result, 'hasil', SORT_DESC);
	return $result;
}


function array_sort($array, $on, $order=SORT_ASC){ //fungsi sorting

    $new_array = array();
    $sortable_array = array();

    if (count($array) > 0) {
        foreach ($array as $k => $v) {
            if (is_array($v)) {
                foreach ($v as $k2 => $v2) {
                    if ($k2 == $on) {
                        $sortable_array[$k] = $v2;
                    }
                }
            } else {
                $sortable_array[$k] = $v;
            }
        }

        switch ($order) {
            case SORT_ASC:
                asort($sortable_array);
                break;
            case SORT_DESC:
                arsort($sortable_array);
                break;
        }

        foreach ($sortable_array as $k => $v) {
            $new_array[$k] = $array[$k];
        }
    }
    $new_array=array_values($new_array);
    return $new_array;
}

$admin 			= new admin($mysqli);
$pendaftaran 	= new pendaftaran($mysqli);
$penilaian 		= new penilaian($mysqli);
$penilaiancalon = new penilaiancalon($mysqli);
$bobot_saw 		= new bobot_saw($mysqli);

?>