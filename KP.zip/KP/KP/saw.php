<?php 
//fungsi SAW
function simple_additive_weight($data, $bobot){
	$result=null;
	//mencari nilai maks tes tulis
	$temp=null;
	for ($i=0; $i < count($data); $i++) { 
		$temp[]=$data[$i]['nilai_tulis'];
	}
	$maksNilaiTulis=max($temp);
	//menghitung nilai kriteria tes tulis
	for ($i=0; $i < count($data); $i++) { 
		$result[$i]['kriteriaTulis']=$data[$i]['nilai_tulis']/$maksNilaiTulis;
	}
	//mencari nilai maks tes wawancara
	$temp=null;
	for ($i=0; $i < count($data); $i++) { 
		$temp[]=$data[$i]['nilai_wawancara'];
	}
	$maksNilaiWawancara=max($temp);
	//menghitung nilai kriteria tes wawancara
	for ($i=0; $i < count($data); $i++) { 
		$result[$i]['kriteriaWawancara']=$data[$i]['nilai_wawancara']/$maksNilaiWawancara;
	}
	//mencari nilai min umur
	$temp=null;
	for ($i=0; $i < count($data); $i++) { 
		$temp[]=$data[$i]['umur'];
	}
	$minUmur=min($temp);
	//menghitung nilai kriteria umur
	for ($i=0; $i < count($data); $i++) { 
		$result[$i]['kriteriaUmur']=$minUmur/$data[$i]['umur'];
	}
	//mencari nilai maks pengalaman
	$temp=null;
	for ($i=0; $i < count($data); $i++) { 
		$temp[]=$data[$i]['lama_pengalaman'];
	}
	$maksLamaPengalaman=max($temp);
	//menghitung nilai kriteria pengalaman
	for ($i=0; $i < count($data); $i++) { 
		$result[$i]['kriteriaPengalaman']=$data[$i]['lama_pengalaman']/$maksLamaPengalaman;
	}
	//mencari nilai min jarak
	$temp=null;
	for ($i=0; $i < count($data); $i++) { 
		$temp[]=$data[$i]['jarak_rmh'];
	}
	$minJarak=min($temp);	
	//menghitung nilai kriteria jarak
	for ($i=0; $i < count($data); $i++) { 
		$result[$i]['kriteriaJarak']=$minJarak/$data[$i]['jarak_rmh'];
	}
	//menghitung hasil kriteria dikali bobot
	echo print_r($bobot);
	for ($i=0; $i < count($data); $i++) { 
		$result[$i]['hasil']=$result[$i]['kriteriaTulis']*$bobot['bobot_tulis']+$result[$i]['kriteriaWawancara']*$bobot['bobot_wawancara']+$result[$i]['kriteriaUmur']*$bobot['bobot_umur']+$result[$i]['kriteriaPengalaman']*$bobot['bobot_pengalaman']+$result[$i]['kriteriaJarak']*$bobot['bobot_jarakrmh'];
	}

	$result=array_sort($result, 'hasil', SORT_DESC);
	return $result;
}


function array_sort($array, $on, $order=SORT_ASC){ //fungsi sorting

    $new_array = array();
    $sortable_array = array();

    if (count($array) > 0) {
        foreach ($array as $k => $v) {
            if (is_array($v)) {
                foreach ($v as $k2 => $v2) {
                    if ($k2 == $on) {
                        $sortable_array[$k] = $v2;
                    }
                }
            } else {
                $sortable_array[$k] = $v;
            }
        }

        switch ($order) {
            case SORT_ASC:
                asort($sortable_array);
                break;
            case SORT_DESC:
                arsort($sortable_array);
                break;
        }

        foreach ($sortable_array as $k => $v) {
            $new_array[$k] = $array[$k];
        }
    }
    $new_array=array_values($new_array);
    return $new_array;
}


echo "<pre>";

//besok ini dihapus kalau sistem sudah jadi//

//bikin koneksi
$connection=mysqli_connect("localhost","root","","kp_2");
//mendapat kode pendaftaran
$id_pendaftaran="2";
//memanggil data bobot
$query="select * from bobot_saw where id_pendaftaran='2'";
$mysql=mysqli_query($connection, $query);
$bobot=mysqli_fetch_assoc($mysql);
//memanggil data nilai pendaftar
$query="select * from penilaian where id_pendaftaran='2' and nilai_tulis <> '0' and nilai_wawancara <> '0' and umur <> '0' and lama_pengalaman <> '0' and jarak_rmh <> '0'";
$mysql=mysqli_query($connection, $query);
$data=null;
while ($result=mysqli_fetch_assoc($mysql)) {
	$data[]=$result;
}
//memanggil fungsi SAW
$pegawai=simple_additive_weight($data, $bobot);
//menampilkan data
echo print_r($pegawai);